"""
Created on 21 de mar de 2018

@author: clebson
"""
from hydrocomp.files.fileRead import FileRead


class Semarh(FileRead):
    """
    class files read: Secretaria do Meio Ambiente e Recursos Hidreicos - SEMARH
    """
    source = "  SEMARH"
    extension = None

    def __init__(self, path_file, name):
        pass

__all__ = ['genextreme', 'genpareto', 'hydrogram_clean', 'boxplot',
           'hydrogram_parcial', 'hydrogram_annual', 'comparationdistribution']
